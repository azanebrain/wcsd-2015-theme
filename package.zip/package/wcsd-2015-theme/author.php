<?php
// The author template
// https://codex.wordpress.org/Author_Templates
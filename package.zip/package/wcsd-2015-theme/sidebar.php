<?php
/**
 * A sidebar template
 *
 * @package WordPress
 * @subpackage WCSD 2015 Theme
 *
 * @link https://codex.wordpress.org/Function_Reference/dynamic_sidebar
 */
?>

This is just the blank sidebar.